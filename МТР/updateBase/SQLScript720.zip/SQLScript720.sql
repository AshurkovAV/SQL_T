CREATE TABLE [dbo].[FactEconomicFin](
	[EconomicFinId] [int] IDENTITY(1,1) NOT NULL,
	[FinOrder] [nvarchar](254) NULL,
	[FinDate] [datetime] NULL,
	[FinDateBegin] [datetime] NULL,
	[FinDateEnd] [datetime] NULL,
	[TotalAmount] [money] NULL,
	[Kol] [int] NULL,
	[SumPayment] [money] NULL,
	[CancelKol] [int] NULL,
	[SumCancelPayment] [money] NULL,
	[Body] [varbinary](max) NULL,
	[Comments] [nvarchar](254) NULL,
PRIMARY KEY CLUSTERED 
(
	[EconomicFinId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


